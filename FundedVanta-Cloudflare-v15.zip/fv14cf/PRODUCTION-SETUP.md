# FundedVanta Production Foundation

This package adds a production-ready backend foundation without hardcoding provider secrets.

## 1. Supabase database
1. Create a Supabase project.
2. Open SQL Editor.
3. Run `supabase-schema.sql`.
4. In Settings -> API Keys create/use the server-side Secret key (`sb_secret_...`). Legacy `service_role` can be used temporarily if required.
5. In Netlify Environment Variables add:
   - `SUPABASE_URL` = your Supabase project URL
   - `SUPABASE_SECRET_KEY` = your server-side secret key
6. Never put the secret key in `index.html` or any browser code.

## 2. Required security variables
- `SESSION_SECRET` = long random secret
- `PASSWORD_PEPPER` = long random secret
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`

## 3. Existing services
- `TWELVE_DATA_API_KEY`
- `RESEND_API_KEY`
- `RESEND_FROM`
- `FUNDEDVANTA_APP_URL`

## 4. Monitoring
Set `SENTRY_DSN` after creating a Sentry project. The current package exposes monitoring readiness at `/api/health`; full frontend/error instrumentation can be enabled after the DSN is supplied.

## 5. Payments (sandbox first)
Choose ONE provider initially:
- Cashfree: `CASHFREE_CLIENT_ID`, `CASHFREE_CLIENT_SECRET`, `CASHFREE_WEBHOOK_SECRET`
- Razorpay: `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`

Webhook endpoint:
`/api/payment-webhook`

For Cashfree, configure the webhook provider header as `x-fv-provider: cashfree`; for Razorpay use `x-fv-provider: razorpay`. Do not activate live money movement until provider approval and legal/compliance review are complete.

## 6. KYC
Sumsub sandbox/production values:
- `SUMSUB_APP_TOKEN`
- `SUMSUB_SECRET_KEY`
- `SUMSUB_WEBHOOK_SECRET` (if separate from API secret)

Webhook endpoint:
`/api/kyc-webhook`

Configure the webhook with HTTPS and HMAC verification. The handler supports SHA-1/SHA-256/SHA-512 digest headers.

## 7. Payouts
The package creates a controlled payout-request queue at `/api/payouts`. Actual provider payout execution should remain server-side and only run after KYC/risk/admin approval and provider sandbox tests.

For Cashfree payout execution later, add the provider's current payout credentials separately; do not reuse payment secrets unless the provider explicitly documents that behavior.

## 8. Fraud / audit
- `/api/fraud-event` creates admin-reviewed fraud flags.
- `/api/audit` records administrative actions.
- Production schema includes risk_events, fraud_events, payment_events and audit_logs.

## 9. Health check
Open:
`/api/health`

It reports whether database, market data, email, monitoring, payment, KYC and payout credentials are configured. It does not return secrets.

## 10. Go-live sequence
Sandbox -> webhook verification -> DB persistence -> reconciliation -> KYC tests -> fraud/risk tests -> payout approval tests -> backups/alerts -> legal/compliance review -> provider live approval -> only then production money movement.

## 11. Live market terminal
The browser terminal now uses the server-side `/api/market` function. Traders do not enter provider credentials in the browser.

- `TWELVE_DATA_API_KEY` must be present in Netlify environment variables.
- Quote polling refreshes the instrument strip and open-position P/L.
- Historical OHLC is requested for the selected symbol/timeframe so the chart does not rely on fake browser-generated candles.
- Supported chart controls include 1m, 3m, 5m, 15m, 30m, 1H, 2H, 4H, 8H, 1D, 1W, 1M, 3M, 6M and 1Y views.
- Twelve Data currently documents historical intervals including 1min, 5min, 15min, 30min, 45min, 1h, 2h, 4h, 8h, 1day, 1week and 1month; longer FundedVanta buttons are rendered as date-range views over supported data. 
