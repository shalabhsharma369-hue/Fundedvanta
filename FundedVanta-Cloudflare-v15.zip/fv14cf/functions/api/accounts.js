import handler from '../lib/accounts.mjs';
export async function onRequest(context) { return handler(context.request, context.env); }
