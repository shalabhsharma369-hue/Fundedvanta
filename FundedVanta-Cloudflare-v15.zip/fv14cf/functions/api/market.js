import handler from '../lib/market.mjs';
export async function onRequest(context) { return handler(context.request, context.env); }
