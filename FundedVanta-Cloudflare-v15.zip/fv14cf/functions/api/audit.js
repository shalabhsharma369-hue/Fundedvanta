import handler from '../lib/audit.mjs';
export async function onRequest(context) { return handler(context.request, context.env); }
