import handler from '../lib/fraud-event.mjs';
export async function onRequest(context) { return handler(context.request, context.env); }
