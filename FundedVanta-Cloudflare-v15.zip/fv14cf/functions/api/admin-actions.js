import handler from '../lib/admin-actions.mjs';
export async function onRequest(context) { return handler(context.request, context.env); }
