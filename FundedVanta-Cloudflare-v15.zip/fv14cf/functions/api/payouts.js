import handler from '../lib/payouts.mjs';
export async function onRequest(context) { return handler(context.request, context.env); }
