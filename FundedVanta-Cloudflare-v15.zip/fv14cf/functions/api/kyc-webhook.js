import handler from '../lib/kyc-webhook.mjs';
export async function onRequest(context) { return handler(context.request, context.env); }
