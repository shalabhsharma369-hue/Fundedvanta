import handler from '../lib/consume-password-reset.mjs';
export async function onRequest(context) { return handler(context.request, context.env); }
