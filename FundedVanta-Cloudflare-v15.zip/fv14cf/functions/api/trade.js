import handler from '../lib/trade.mjs';
export async function onRequest(context) { return handler(context.request, context.env); }
