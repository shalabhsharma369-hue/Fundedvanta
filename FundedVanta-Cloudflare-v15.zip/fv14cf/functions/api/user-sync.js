import handler from '../lib/user-sync.mjs';
export async function onRequest(context) { return handler(context.request, context.env); }
