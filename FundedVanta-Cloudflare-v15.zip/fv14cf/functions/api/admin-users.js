import handler from '../lib/admin-users.mjs';
export async function onRequest(context) { return handler(context.request, context.env); }
