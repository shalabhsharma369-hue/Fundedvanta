import handler from '../lib/payment-webhook.mjs';
export async function onRequest(context) { return handler(context.request, context.env); }
