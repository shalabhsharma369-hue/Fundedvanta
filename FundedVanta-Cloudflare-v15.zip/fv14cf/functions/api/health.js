import handler from '../lib/health.mjs';
export async function onRequest(context) { return handler(context.request, context.env); }
