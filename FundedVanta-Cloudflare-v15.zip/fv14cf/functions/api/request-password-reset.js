import handler from '../lib/request-password-reset.mjs';
export async function onRequest(context) { return handler(context.request, context.env); }
