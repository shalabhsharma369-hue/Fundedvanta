-- FundedVanta production foundation schema.
-- Run this in Supabase SQL Editor before setting SUPABASE_SECRET_KEY.
create extension if not exists pgcrypto;

create table if not exists public.health_probe(id integer primary key default 1, checked_at timestamptz not null default now());
insert into public.health_probe(id) values (1) on conflict (id) do nothing;

create table if not exists public.app_users(id uuid primary key default gen_random_uuid(), email text unique not null, name text not null default 'Trader', role text not null default 'trader' check(role in ('trader','admin','support','risk')), status text not null default 'active', phone text, billing_address jsonb, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists public.accounts(id text primary key, user_email text not null references public.app_users(email), plan text not null, size numeric not null, phase integer not null default 1, status text not null, balance numeric not null, equity numeric not null, day_start_equity numeric not null, return_pct numeric not null default 0, daily_loss_pct numeric not null default 0, max_loss_pct numeric not null default 0, rules jsonb not null default '{}'::jsonb, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists public.orders(id text primary key, account_id text references public.accounts(id), user_email text not null, symbol text not null, side text not null, lots numeric not null, entry_price numeric not null, stop_loss numeric, take_profit numeric, status text not null default 'open', created_at timestamptz not null default now(), closed_at timestamptz, pnl numeric);
create table if not exists public.positions(id text primary key, order_id text references public.orders(id), account_id text references public.accounts(id), symbol text not null, side text not null, lots numeric not null, entry_price numeric not null, current_price numeric, stop_loss numeric, take_profit numeric, floating_pnl numeric not null default 0, opened_at timestamptz not null default now(), closed_at timestamptz);
create table if not exists public.trades(id text primary key, order_id text references public.orders(id), account_id text references public.accounts(id), user_email text not null, symbol text not null, side text not null, lots numeric not null, entry_price numeric not null, exit_price numeric, pnl numeric, opened_at timestamptz, closed_at timestamptz);
create table if not exists public.daily_metrics(id uuid primary key default gen_random_uuid(), account_id text references public.accounts(id), metric_date date not null, start_equity numeric not null, low_equity numeric not null, high_equity numeric not null, daily_loss_pct numeric not null default 0, unique(account_id,metric_date));
create table if not exists public.risk_events(id uuid primary key default gen_random_uuid(), account_id text, user_email text, event_type text not null, severity text not null default 'medium', details jsonb not null default '{}'::jsonb, created_at timestamptz not null default now());
create table if not exists public.challenge_events(id uuid primary key default gen_random_uuid(), account_id text, event_type text not null, from_status text, to_status text, details jsonb not null default '{}'::jsonb, created_at timestamptz not null default now());
create table if not exists public.payments(id uuid primary key default gen_random_uuid(), provider text not null, provider_payment_id text unique, order_id text, user_email text, amount numeric, currency text default 'INR', status text not null default 'pending', raw_data jsonb, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists public.payment_events(id uuid primary key default gen_random_uuid(), provider text not null, event_id text not null, event_type text, payload jsonb not null, received_at timestamptz not null default now(), unique(provider,event_id));
create table if not exists public.kyc_applications(id uuid primary key default gen_random_uuid(), external_user_id text unique not null, user_email text, provider text not null default 'sumsub', applicant_id text, status text not null default 'PENDING', raw_event jsonb, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists public.payout_requests(id uuid primary key default gen_random_uuid(), user_email text not null, account_id text, amount numeric not null, currency text not null default 'USD', method text not null, destination_masked text, status text not null default 'pending', provider text, provider_reference text, rejection_reason text, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists public.payout_transactions(id uuid primary key default gen_random_uuid(), payout_request_id uuid references public.payout_requests(id), provider text, provider_reference text, status text, raw_data jsonb, created_at timestamptz not null default now());
create table if not exists public.fraud_events(id uuid primary key default gen_random_uuid(), user_email text, account_id text, flag text not null, severity text not null default 'medium', score numeric default 0, evidence jsonb not null default '{}'::jsonb, status text not null default 'open', reviewed_by text, reviewed_at timestamptz, created_at timestamptz not null default now());
create table if not exists public.audit_logs(id uuid primary key default gen_random_uuid(), actor_email text, actor_role text, action text not null, entity_type text, entity_id text, metadata jsonb not null default '{}'::jsonb, created_at timestamptz not null default now());

create index if not exists idx_accounts_user on public.accounts(user_email);
create index if not exists idx_orders_account on public.orders(account_id);
create index if not exists idx_trades_account on public.trades(account_id);
create index if not exists idx_risk_account on public.risk_events(account_id,created_at desc);
create index if not exists idx_audit_created on public.audit_logs(created_at desc);
create index if not exists idx_fraud_status on public.fraud_events(status,created_at desc);

-- Server uses the Supabase secret key, but browser exposure should remain denied.
alter table public.app_users enable row level security;
alter table public.accounts enable row level security;
alter table public.orders enable row level security;
alter table public.positions enable row level security;
alter table public.trades enable row level security;
alter table public.payments enable row level security;
alter table public.payment_events enable row level security;
alter table public.kyc_applications enable row level security;
alter table public.payout_requests enable row level security;
alter table public.payout_transactions enable row level security;
alter table public.fraud_events enable row level security;
alter table public.audit_logs enable row level security;

-- No anonymous/authenticated policies are intentionally created here. Backend-only access is the default for this Netlify architecture.
