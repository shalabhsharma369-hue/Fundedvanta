# FundedVanta — Cloudflare Free Setup

This build replaces the Netlify Functions/Netlify Blobs dependency with Cloudflare Pages Functions + Cloudflare KV.

## 1. Create a KV namespace

In Cloudflare Dashboard:

1. Workers & Pages → KV.
2. Create namespace.
3. Name it `FUNDEDVANTA` (any name is fine).
4. Copy the namespace ID.

## 2. Connect the project

Cloudflare Pages Functions are deployed through Git integration or Wrangler; direct dashboard upload does not support Functions.

Recommended:

1. Create a GitHub repository named `fundedvanta`.
2. Upload the contents of this ZIP to the repository root.
3. Cloudflare → Workers & Pages → Create application → Pages → Connect to Git.
4. Select the GitHub repository.
5. Production branch: `main`.
6. Build command: `exit 0`.
7. Build output directory: `.`.

## 3. Add the KV binding

In the Cloudflare Pages project settings, add a KV binding:

- Variable/binding name: `FV_KV`
- KV namespace: the namespace created above

The application uses this KV binding for trader accounts, login credentials and password-reset records.

## 4. Add environment variables

Add these as production secrets/variables in Cloudflare:

Required for the core app:

- `PASSWORD_PEPPER` — long random secret
- `SESSION_SECRET` — another long random secret
- `ADMIN_EMAIL` — your admin login email
- `ADMIN_PASSWORD` — strong admin password
- `TWELVE_DATA_API_KEY` — your server-side market-data key
- `FUNDEDVANTA_APP_URL` — your Cloudflare Pages URL, e.g. `https://fundedvanta.pages.dev`

Optional email:

- `RESEND_API_KEY`
- `RESEND_FROM`

Optional production database/monitoring/payment/KYC integrations from the existing production foundation:

- `SUPABASE_URL`
- `SUPABASE_SECRET_KEY`
- `SENTRY_DSN`
- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`
- `RAZORPAY_WEBHOOK_SECRET`
- `CASHFREE_CLIENT_ID`
- `CASHFREE_CLIENT_SECRET`
- `CASHFREE_WEBHOOK_SECRET`
- `SUMSUB_APP_TOKEN`
- `SUMSUB_SECRET_KEY`
- `SUMSUB_WEBHOOK_SECRET`
- `CASHFREE_PAYOUT_CLIENT_ID`
- `CASHFREE_PAYOUT_CLIENT_SECRET`

Do not put API keys inside `index.html` or any browser-side JavaScript.

## 5. Important payment note

The current free/test checkout flow is intentionally not a production payment verification system. Before taking real customer payments, connect Razorpay/Cashfree webhooks and activate paid accounts only after server-side signature verification.

## 6. What this build keeps

- FundedVanta branding/UI
- Free first-account flow
- SHALABH Buy 1 Get 1 flow (test entitlement only)
- 2-Step Standard / 2-Step Pro / 1-Step Flex / Vanta Strict / Instant
- virtual/simulated trading terminal
- server-managed market feed
- SL/TP, pending orders, bid/ask, fullscreen terminal
- account dashboard, account history and challenge rules
- password reset email flow when Resend is configured
- optional Supabase production audit/payment/KYC/payout integrations
